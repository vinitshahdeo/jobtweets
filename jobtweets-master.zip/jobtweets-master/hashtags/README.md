Sentiment analysis of popular hashtags related to job offers.

•	#Jobs
•	#Careers
•	#JobOpening
•	#JobOpportunities
•	#Hiring
