#### Abstract

We have collected the tweets related to jobs using python language and applied machine learning algorithms and sentiment analysis to find the job opportunities. Some specific hashtags played major role in finding job opportunities.
